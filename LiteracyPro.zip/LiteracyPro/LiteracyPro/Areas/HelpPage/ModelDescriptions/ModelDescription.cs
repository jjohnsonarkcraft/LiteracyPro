using System;

namespace LiteracyPro.Areas.HelpPage.ModelDescriptions
{
    #pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
    /// <summary>
    /// Describes a type model.
    /// </summary>
    public abstract class ModelDescription
    {
        public string Documentation { get; set; }

        public Type ModelType { get; set; }

        public string Name { get; set; }
    }
}