namespace LiteracyPro.Areas.HelpPage.ModelDescriptions
{
    #pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
    public class DictionaryModelDescription : KeyValuePairModelDescription
    {
    }
}