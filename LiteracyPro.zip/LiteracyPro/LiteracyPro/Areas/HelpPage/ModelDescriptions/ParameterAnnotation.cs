using System;

namespace LiteracyPro.Areas.HelpPage.ModelDescriptions
{
    #pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
    public class ParameterAnnotation
    {
        public Attribute AnnotationAttribute { get; set; }

        public string Documentation { get; set; }
    }
}