using System;
using System.Reflection;

namespace LiteracyPro.Areas.HelpPage.ModelDescriptions
{
    #pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
    public interface IModelDocumentationProvider
    {
        string GetDocumentation(MemberInfo member);

        string GetDocumentation(Type type);
    }
}