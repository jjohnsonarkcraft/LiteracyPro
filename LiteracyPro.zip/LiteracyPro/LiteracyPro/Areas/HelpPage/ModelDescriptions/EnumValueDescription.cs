namespace LiteracyPro.Areas.HelpPage.ModelDescriptions
{
    #pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
    public class EnumValueDescription
    {
        public string Documentation { get; set; }

        public string Name { get; set; }

        public string Value { get; set; }
    }
}