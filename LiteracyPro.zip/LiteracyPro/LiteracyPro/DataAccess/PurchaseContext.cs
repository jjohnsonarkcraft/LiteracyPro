﻿using LiteracyPro.Models;
using System.Data.Entity;

namespace LiteracyPro.DataAccess
{
    #pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
    public class PurchaseContext : DbContext
    {
        public DbSet<Transaction> Transactions { get; set; }
        public DbSet<Category> Categories { get; set; }
    }
}