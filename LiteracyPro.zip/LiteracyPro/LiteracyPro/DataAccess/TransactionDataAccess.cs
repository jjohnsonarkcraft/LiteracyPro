﻿using LiteracyPro.Models;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;

namespace LiteracyPro.DataAccess
{
    #pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
    public class TransactionDataAccess
    {
        public static List<Transaction> GetAll()
        {
            List<Transaction> transactions = new List<Transaction>();

            using (var db = new PurchaseContext())
            {
                var query = from t in db.Transactions.Include(t => t.Category)
                            orderby t.PurchaseDate
                            select t;

                foreach (var transaction in query)
                {
                    if (transaction.Memo == null)
                    {
                        transaction.Memo = string.Empty;
                    }
                    transactions.Add(transaction);
                }
            }

            return transactions;
        }

        public static void Update(Transaction transaction)
        {
            using (var db = new PurchaseContext())
            {
                var dbTransaction = db.Transactions.Where(x => x.Id == transaction.Id).First();
                //EF is doing something funky with saving another instance of Category and 
                //you end up with duplicate categories
                //https://msdn.microsoft.com/en-us/magazine/dn166926.aspx?f=255&MSPPError=-2147217396
                db.Entry(dbTransaction.Category).State = EntityState.Unchanged;
                if (dbTransaction != null)
                {
                    dbTransaction.PayeeName = transaction.PayeeName;
                    dbTransaction.PurchaseAmount = transaction.PurchaseAmount;
                    dbTransaction.PurchaseDate = transaction.PurchaseDate;
                    dbTransaction.Category.Id = transaction.Category.Id;
                    dbTransaction.Memo = transaction.Memo;
                    db.SaveChanges();
                }
            }
        }

        public static void Insert(Transaction transaction)
        {
            using (var db = new PurchaseContext())
            {
                //EF is doing something funky with saving another instance of Category and 
                //you end up with duplicate categories
                db.Entry(transaction.Category).State = EntityState.Unchanged;
                db.Transactions.Add(transaction);
                db.SaveChanges();
            }
        }

        public static void Delete (long id)
        {
            using (var db = new PurchaseContext())
            {
                Transaction toDelete = db.Transactions.Find(id);
                db.Entry(toDelete.Category).State = EntityState.Unchanged;
                db.Transactions.Remove(toDelete);
                db.SaveChanges();
            }
        }

        public static TransactionMetrics GetMetrics()
        {
            TransactionMetrics metrics = new TransactionMetrics();

            using (var db = new PurchaseContext())
            {
                var sum = (from t in db.Transactions select t.PurchaseAmount).Sum();
                metrics.TotalPurchaseAmount = sum.ToString("C");

                var count = db.Database.SqlQuery<int>("SELECT Count(*) FROM dbo.Transactions").First();
                metrics.TotalTransactions = count;

                var average = sum / count;
                metrics.AveragePurchaseAmount = average.ToString("C");
            }

            return metrics;
        }
    }
}