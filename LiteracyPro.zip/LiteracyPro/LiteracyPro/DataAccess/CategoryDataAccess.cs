﻿using LiteracyPro.Models;
using System.Collections.Generic;
using System.Linq;

namespace LiteracyPro.DataAccess
{
    #pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
    public class CategoryDataAccess
    {
        public static List<Category> GetAll()
        {
            List<Category> categories = new List<Category>();

            using (var db = new PurchaseContext())
            {
                var query = from t in db.Categories
                            orderby t.Description
                            select t;

                foreach (var category in query)
                {
                    categories.Add(category);
                }
            }

            return categories;
        }
    }
}