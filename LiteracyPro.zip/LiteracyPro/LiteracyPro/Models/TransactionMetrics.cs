﻿namespace LiteracyPro.Models
{
    #pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
    public class TransactionMetrics
    {
        public long TotalTransactions { get; set; }
        public string TotalPurchaseAmount { get; set; }
        public string AveragePurchaseAmount { get; set; }
    }
}