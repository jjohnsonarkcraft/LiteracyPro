﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LiteracyPro.Models
{
    #pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
    public class Transaction
    {
        public long Id { get; set; }
        public string PayeeName { get; set; }
        public Decimal PurchaseAmount { get; set; }
        public DateTime PurchaseDate { get; set; }
        public string Memo { get; set; }
        public Category Category { get; set; }

        public Transaction()
        {
            Category = new Category();
        }
    }
}