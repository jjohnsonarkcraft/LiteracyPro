﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LiteracyPro.Models
{
    #pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
    public class Category
    {
        public long Id { get; set; }
        public string Description { get; set; }
    }
}