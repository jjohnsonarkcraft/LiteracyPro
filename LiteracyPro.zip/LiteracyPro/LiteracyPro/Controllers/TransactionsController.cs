﻿using LiteracyPro.DataAccess;
using LiteracyPro.Models;
using System.Collections.Generic;
using System.Web.Http;

namespace LiteracyPro.Controllers
{
    /// <summary>
    /// Transaction controller provides service methods to interact with transactions (purchases)
    /// </summary>
    public class TransactionsController : ApiController
    {
        /// <summary>
        /// Gets a list of all transactions
        /// </summary>
        /// <returns>List of Transactions</returns>
        // GET: api/Transactions
        [HttpGet]
        public List<Transaction> Get()
        {
            //would need to add paging and all for a production app
            List<Transaction> transactions = TransactionDataAccess.GetAll();

            return transactions;
        }

        /// <summary>
        /// Updates or Inserts the passed Transaction to the database table transaction.
        /// </summary>
        /// <param name="transaction"></param>
        // POST: api/Transactions
        [HttpPost]
        public void Post([FromBody] Transaction transaction)
        {
            if(transaction != null)
            {
                if(transaction.Id == 0)
                {
                    //it's an insert
                    TransactionDataAccess.Insert(transaction);                    
                }
                else
                {
                    //it's an update
                    TransactionDataAccess.Update(transaction);
                }
            }
        }

        /// <summary>
        /// Deletes a transaction from the database using the provided id
        /// </summary>
        /// <param name="id"></param>
        // DELETE: api/Transactions/5
        [HttpDelete]
        public void Delete(int id)
        {
            TransactionDataAccess.Delete(id);
        }

        /// <summary>
        /// Get the purchase metrics for Total transactions, Total Amount, and Average Amount
        /// </summary>
        /// <returns>Instance of TransactionMetrics</returns>
        [Route("api/Transactions/Metrics")]
        [HttpGet]
        public TransactionMetrics Metrics()
        {
            TransactionMetrics metrics = TransactionDataAccess.GetMetrics();
            return metrics;
        }
    }
}
