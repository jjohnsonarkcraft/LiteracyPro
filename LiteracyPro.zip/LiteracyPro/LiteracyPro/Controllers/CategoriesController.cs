﻿using LiteracyPro.DataAccess;
using LiteracyPro.Models;
using System.Collections.Generic;
using System.Web.Http;

namespace LiteracyPro.Controllers
{
    /// <summary>
    /// Categories are a way to group purchases
    /// </summary>
    public class CategoriesController : ApiController
    {
        // GET: api/Categories
        /// <summary>
        /// Gets a list of all categories
        /// </summary>
        /// <returns>List of Categories</returns>
        [HttpGet]
        public List<Category> Get()
        {
            List<Category> categories = CategoryDataAccess.GetAll();
            return categories;
        }        
    }
}
