﻿using LiteracyPro.DataAccess;
using System.Web.Mvc;

namespace LiteracyPro.Controllers
{
    /// <summary>
    /// Returns the client side elements for purchase tracker
    /// </summary>
    public class HomeController : Controller
    {
        #pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
        public ActionResult Index()
        {
            ViewBag.Title = "Home Page";            

            return View();
        }
    }
}
